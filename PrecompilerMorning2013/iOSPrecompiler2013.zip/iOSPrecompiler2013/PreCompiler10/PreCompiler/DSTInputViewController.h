//
//  DSTInputViewController.h
//  PreCompiler
//
//  Created by Daniel Steinberg on 1/7/13.
//  Copyright (c) 2013 Dim Sum Thinking. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DSTInputViewController : UIViewController
@property (strong, nonatomic) UIColor *backgroundColor;
@property (strong, nonatomic) NSString *signInString;
@end
